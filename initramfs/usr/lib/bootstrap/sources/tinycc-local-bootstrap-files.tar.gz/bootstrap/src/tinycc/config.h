#define TCC_VERSION "0.9.28"
#define CONFIG_TCC_BACKTRACE 0
#define CONFIG_TCC_BCHECK 0
#define CONFIG_TCC_MUSL 1
#if defined(__x86_64__)
#define CONFIG_TCC_ELFINTERP "/lib/ld-musl-x86_64.so.1"
#elif defined(__aarch64__)
#define CONFIG_TCC_ELFINTERP "/lib/ld-musl-aarch64.so.1"
#else
#error "This bootstrap supports only x86_64 and aarch64 musl"
#endif
/* The cc wrapper adds the bootstrap runtime explicitly where needed. */
#define TCC_LIBTCC1 ""
