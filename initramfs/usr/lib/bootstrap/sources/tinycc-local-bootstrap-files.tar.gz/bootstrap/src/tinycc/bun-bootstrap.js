import { cc } from 'bun:ffi';
import { resolve } from 'node:path';
const root = import.meta.dir;
console.time('compile TinyCC with Bun.cc');
const compiler = cc({
  source: resolve(root, 'bun-bootstrap.c'),
  library: ['gcc_s'],
  flags: ['-L/usr/lib', '-L/lib'],
  include: [root, resolve(root, 'include'), '/usr/include'],
  symbols: { bootstrap_compile: { args: ['cstring', 'cstring', 'cstring', 'int'], returns: 'int' } },
});
console.timeEnd('compile TinyCC with Bun.cc');
const z = s => Buffer.from(s + '\0');
const result = compiler.symbols.bootstrap_compile(z(resolve(root, process.argv[2] ?? 'bun-hello.c')), z(resolve(root, process.argv[3] ?? 'bun-hello')), z(root), Number(process.argv[4] ?? 1));
console.log('TinyCC output result:', result);
compiler.close();
process.exitCode = result === 0 ? 0 : 1;
