#!/usr/bin/env bun
// Use the numbered bootstrap flow's shared, dual-architecture builder.
import { buildTcc } from "/bootstrap/lib/tcc-build.js";
await buildTcc();
