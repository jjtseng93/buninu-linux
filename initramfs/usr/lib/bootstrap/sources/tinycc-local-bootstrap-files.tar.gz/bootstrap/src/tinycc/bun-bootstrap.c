#include "libtcc.c"

int bootstrap_compile(const char *source, const char *output, const char *root, int standalone) {
    TCCState *s = tcc_new();
    if (!s) return 10;
    tcc_set_lib_path(s, root);
    if (standalone) tcc_set_options(s, "-nostdlib -static");
    int result = tcc_set_output_type(s, TCC_OUTPUT_EXE);
    if (!result) result = tcc_add_file(s, source);
    if (!result && !standalone) {
        tcc_add_library_path(s, "/usr/lib");
        result = tcc_add_library(s, "gcc_s");
    }
    if (!result) result = tcc_output_file(s, output);
    tcc_delete(s);
    return result;
}

/* Bun supplies most x64 helpers already; do not include all of libtcc1.c. */
#include "bun-x64-runtime.c"
