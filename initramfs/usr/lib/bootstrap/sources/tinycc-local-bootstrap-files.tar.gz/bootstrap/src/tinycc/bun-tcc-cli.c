#define CONFIG_TCCDIR "/bootstrap/toolchain/lib/tcc"
#define main bootstrap_tcc_main
#include "tcc.c"
#undef main
int main(int argc, char **argv) {
    return bootstrap_tcc_main(argc, argv);
}

/* The standalone compiler does not inherit Bun's runtime helpers. */
#if defined(__x86_64__)
#include "lib/libtcc1.c"
#include "lib/va_list.c"
#endif
