# Bootstrap source overlay

- Run `bun /bootstrap/3.gen-musl-dev.js` first.
- Run `bun /bootstrap/4.build-tcc.js` to build and verify TinyCC.
- Sources: `/bootstrap/src/tinycc`.
- Compiler: `/bootstrap/toolchain/bin/tcc`; launcher: `/bin/cc`.
- Runtime helpers: `/bootstrap/toolchain/lib/tcc`.
- Intermediate objects and smoke tests: `/bootstrap/build/tinycc`.
- See `/bootstrap/README.md` for the complete numbered flow.
