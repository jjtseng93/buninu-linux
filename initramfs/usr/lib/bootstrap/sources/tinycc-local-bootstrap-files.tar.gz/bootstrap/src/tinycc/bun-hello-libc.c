#include <stdio.h>
#include <stdlib.h>

static int square(int x) { return x * x; }
int main(void) {
    int *values = malloc(5 * sizeof(*values));
    if (!values) return 1;
    int sum = 0;
    for (int i = 0; i < 5; ++i) sum += values[i] = square(i + 1);
    printf("Hello from libc: sum=%d\n", sum);
    free(values);
    return sum == 55 ? 0 : 2;
}
