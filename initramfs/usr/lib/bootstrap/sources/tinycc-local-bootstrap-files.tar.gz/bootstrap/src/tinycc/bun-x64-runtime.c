/* Supply the signed conversion missing from Bun.cc's x64 runtime.
 * libgcc_s supplies the unsigned conversion. Negate as unsigned so the
 * representable INT64_MIN case does not overflow a signed intermediate.
 * Inputs outside the signed 64-bit range retain C's undefined conversion
 * semantics; this is not a saturating conversion API.
 */
#if defined(__x86_64__)
extern unsigned long long __fixunsxfdi(long double value);

long long __fixxfdi(long double value) {
    if (value >= 0)
        return (long long)__fixunsxfdi(value);
    return (long long)(0ULL - __fixunsxfdi(-value));
}
#endif
