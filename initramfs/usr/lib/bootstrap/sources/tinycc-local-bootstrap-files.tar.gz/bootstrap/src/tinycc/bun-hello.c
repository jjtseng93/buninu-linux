void _start(void) {
    const char *message = "Hello from nested TCC\n";
    __asm__ volatile(
        "mov x1, %0\n"
        "mov x0, #1\n"
        "mov x2, #21\n"
        "mov x8, #64\n"
        ".long 0xd4000001\n" /* svc #0; TinyCC's assembler lacks its mnemonic */
        "mov x0, #0\n"
        "mov x8, #93\n"
        ".long 0xd4000001\n"
        : : "r"(message) : "x0", "x1", "x2", "x8", "memory"
    );
}
