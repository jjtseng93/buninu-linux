/* Exercise conversions and variadic calls without constant folding. */
#include <limits.h>
#include <stdarg.h>
#include <stdio.h>

static long long to_signed(long double value) {
    volatile long double input = value;
    return (long long)input;
}
static long double from_unsigned(unsigned long long value) {
    volatile unsigned long long input = value;
    return (long double)input;
}
static long long sum_integers(int count, ...) {
    va_list ap;
    va_start(ap, count);
    long long sum = 0;
    for (int i = 0; i < count; ++i) sum += va_arg(ap, long long);
    va_end(ap);
    return sum;
}
static double sum_doubles(int count, ...) {
    va_list ap;
    va_start(ap, count);
    double sum = 0;
    for (int i = 0; i < count; ++i) sum += va_arg(ap, double);
    va_end(ap);
    return sum;
}
static long double sum_extended(int count, ...) {
    va_list ap;
    va_start(ap, count);
    long double sum = 0;
    for (int i = 0; i < count; ++i) sum += va_arg(ap, long double);
    va_end(ap);
    return sum;
}
int runtime_check(void) {
    if (to_signed(12.75L) != 12 || to_signed(-12.75L) != -12) return 1;
    if (to_signed(0.0L) != 0 || to_signed(-0.75L) != 0) return 2;
    if (to_signed(9007199254740993.0L) != 9007199254740993LL) return 3;
    if (to_signed(-9223372036854775808.0L) != LLONG_MIN) return 4;
    if (to_signed(9223372036854775807.0L) != LLONG_MAX) return 5;
    if (from_unsigned(ULLONG_MAX) != 18446744073709551615.0L) return 6;
    if (sum_integers(10, 1LL, 2LL, 3LL, 4LL, 5LL, 6LL, 7LL, 8LL, 9LL, 10LL) != 55) return 7;
    if (sum_doubles(12, 1., 2., 3., 4., 5., 6., 7., 8., 9., 10., 11., 12.) != 78.) return 8;
    if (sum_extended(3, 1.25L, -2.5L, 4.0L) != 2.75L) return 9;
    return 0;
}
int main(void) {
    int result = runtime_check();
    printf("runtime conversions/varargs: %s (%d)\n", result ? "FAIL" : "PASS", result);
    return result;
}
